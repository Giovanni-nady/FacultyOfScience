package com.example.facultyofscience;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import javax.security.auth.callback.Callback;

public class MainActivity extends AppCompatActivity {
     WebView webView;
     Intent intent;
     Button mybutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        mybutton = findViewById(R.id.button);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setSupportZoom(true);
        webSettings.setDisplayZoomControls(true);

        webView.setWebViewClient(new Callback());
        webView.loadUrl("http://newportal.asu.edu.eg/science/ar/page/47/private-ads");

    }
    private class Callback extends WebViewClient {
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event)
        {
            return false;
        }
    }
    public void onClick(View view)
    {

       intent=new Intent(this,Activity.class);
        startActivity(intent);

    }




}